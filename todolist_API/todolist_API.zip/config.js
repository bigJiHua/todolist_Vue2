// 全局配置文件
module.exports={
    // 配置一个token加密密钥
    jwtSecretKey : 'todolistVue',
    // token的有效期 3h
    expiresIn : '3h'
}
