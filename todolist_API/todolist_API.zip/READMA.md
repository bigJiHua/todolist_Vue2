# 这是todolist_Vue2 项目的接口文档

### 主入口
./app.js

### 数据库
./database/db.js

### router
./router 存放的所有接口

### router_fun
./router_fun 所有接口的处理方法

### schema
./schema 路由校验规则

### config.js
配置文件

### setting.js
设置文件
